import { useCallback, useState, useEffect } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import * as SMS from "expo-sms";
import { useFocusEffect } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useEmergencyData } from "@/hooks/use-emergency-data";
import { normalizePhone, getGuardianMessageStatuses } from "@/lib/emergency";

export default function GuardiansScreen() {
  const { guardians, addGuardian, removeGuardian } = useEmergencyData();
  const [name, setName] = useState("");
  const [relationship, setRelationship] = useState("");
  const [phone, setPhone] = useState("");
  const [messageStatuses, setMessageStatuses] = useState<Record<string, { status: "success" | "failed"; timestamp: number }>>({});

  // 메시지 상태 로드
  useFocusEffect(
    useCallback(() => {
      const loadStatuses = async () => {
        const statuses = await getGuardianMessageStatuses();
        setMessageStatuses(statuses);
      };
      loadStatuses();
    }, [])
  );

  const resetForm = useCallback(() => {
    setName("");
    setRelationship("");
    setPhone("");
  }, []);

  const save = useCallback(async () => {
    if (!name.trim() || !phone.trim()) {
      Alert.alert("입력 필요", "보호자 이름과 전화번호를 입력해 주세요.");
      return;
    }

    await addGuardian({
      name: name.trim(),
      relationship: relationship.trim() || "보호자",
      phone: phone.trim(),
      appAlertEnabled: false,
    });
    resetForm();
    if (Platform.OS !== "web") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, [addGuardian, name, phone, relationship, resetForm]);

  const sendTest = useCallback(async () => {
    const phones = guardians.map((guardian) => normalizePhone(guardian.phone)).filter(Boolean);
    if (phones.length === 0) {
      Alert.alert("보호자 없음", "테스트 메시지를 받을 보호자를 먼저 등록해 주세요.");
      return;
    }

    if (await SMS.isAvailableAsync()) {
      await SMS.sendSMSAsync(phones, "[SaveMe 테스트] 보호자 연락처가 정상 등록되었습니다.");
    } else {
      Alert.alert("문자 사용 불가", "현재 기기에서는 문자 앱을 열 수 없습니다.");
    }
  }, [guardians]);

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return date.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" });
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "어제";
    } else {
      return date.toLocaleDateString("ko-KR", { month: "short", day: "numeric" });
    }
  };

  return (
    <ScreenContainer className="px-5 pb-4">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View className="gap-5">
            <View>
              <Text className="text-3xl font-bold text-foreground">보호자</Text>
              <Text className="mt-2 text-base leading-6 text-muted">
                SOS 실행 시 응급 메시지를 받을 보호자 연락처를 등록합니다.
              </Text>
            </View>

            <View className="rounded-3xl bg-surface p-5 border border-border gap-4">
              <Text className="text-lg font-bold text-foreground">새 보호자 등록</Text>
              <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="이름" placeholderTextColor="#98A2B3" returnKeyType="next" />
              <TextInput style={styles.input} value={relationship} onChangeText={setRelationship} placeholder="관계 예: 배우자, 부모, 친구" placeholderTextColor="#98A2B3" returnKeyType="next" />
              <TextInput
                style={styles.input}
                value={phone}
                onChangeText={setPhone}
                placeholder="전화번호 예: 01012345678"
                placeholderTextColor="#98A2B3"
                keyboardType="phone-pad"
                returnKeyType="done"
              />
              <TouchableOpacity activeOpacity={0.86} onPress={save} style={styles.addButton}>
                <Text className="text-base font-bold text-white">보호자 추가</Text>
              </TouchableOpacity>
            </View>

            <View className="rounded-3xl bg-surface p-5 border border-border gap-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-lg font-bold text-foreground">등록된 보호자</Text>
                <Text className="text-sm font-bold text-primary">{guardians.length}명</Text>
              </View>
              {guardians.length === 0 ? (
                <Text className="py-8 text-center text-sm leading-6 text-muted">등록된 보호자가 없습니다. 위급 상황 전에 최소 1명을 등록해 주세요.</Text>
              ) : (
                guardians.map((guardian) => (
                  <View key={guardian.id} className="rounded-2xl border border-border bg-background p-4">
                    <View className="flex-row items-start justify-between gap-3">
                      <View className="flex-1">
                        <Text className="text-base font-bold text-foreground">{guardian.name}</Text>
                        <Text className="mt-1 text-sm text-muted">{guardian.relationship} · {guardian.phone}</Text>
                        <View className="mt-3 flex-row items-center gap-2">
                          <IconSymbol name="bell.badge.fill" color="#F79009" size={18} />
                          <Text className="text-xs leading-5 text-muted">
                            앱 간 알림은 서버·푸시 토큰 연동 시 활성화됩니다.
                          </Text>
                        </View>
                        {messageStatuses[guardian.id] && (
                          <View className="mt-3 flex-row items-center gap-2">
                            {messageStatuses[guardian.id].status === "success" ? (
                              <>
                                <Text style={{ fontSize: 16 }}>✅</Text>
                                <View className="flex-1">
                                  <Text className="text-xs leading-5 text-success font-semibold">
                                    메시지 전송 성공
                                  </Text>
                                  <Text className="text-xs leading-4 text-muted">
                                    {formatTime(messageStatuses[guardian.id].timestamp)}
                                  </Text>
                                </View>
                              </>
                            ) : (
                              <>
                                <Text style={{ fontSize: 16 }}>❌</Text>
                                <View className="flex-1">
                                  <Text className="text-xs leading-5 text-error font-semibold">
                                    메시지 전송 실패
                                  </Text>
                                  <Text className="text-xs leading-4 text-muted">
                                    {formatTime(messageStatuses[guardian.id].timestamp)}
                                  </Text>
                                </View>
                              </>
                            )}
                          </View>
                        )}
                      </View>
                      <TouchableOpacity activeOpacity={0.7} onPress={() => removeGuardian(guardian.id)} style={styles.removeButton}>
                        <Text className="text-xs font-bold text-[#B42318]">삭제</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </View>

            <TouchableOpacity activeOpacity={0.86} onPress={sendTest} style={styles.testButton}>
              <Text className="text-base font-bold text-[#175CD3]">테스트 문자 작성</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { paddingTop: 8, paddingBottom: 96 },
  input: {
    minHeight: 52,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#D0D5DD",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    color: "#101828",
    fontSize: 15,
  },
  addButton: {
    height: 54,
    borderRadius: 18,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
  },
  testButton: {
    height: 54,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#B2DDFF",
    backgroundColor: "#EFF8FF",
    alignItems: "center",
    justifyContent: "center",
  },
  removeButton: {
    borderRadius: 999,
    backgroundColor: "#FEF3F2",
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
});

import { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import * as SMS from "expo-sms";
import { useFocusEffect, router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useEmergencyData } from "@/hooks/use-emergency-data";
import { buildEmergencyMessage, getEmergencyLocation, normalizePhone, updateGuardianMessageStatus } from "@/lib/emergency";

function StatusPill({ label, ready }: { label: string; ready: boolean }) {
  return (
    <View className="flex-row items-center gap-2 rounded-full bg-surface px-3 py-2 border border-border">
      <View className={ready ? "h-2.5 w-2.5 rounded-full bg-success" : "h-2.5 w-2.5 rounded-full bg-warning"} />
      <Text className="text-xs font-semibold text-foreground">{label}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const { profile, guardians, isLoading, isProfileReady, hasGuardian, refresh } = useEmergencyData();
  const [isSosRunning, setIsSosRunning] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const insets = useSafeAreaInsets();

  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh]),
  );

  const guardianPhones = useMemo(
    () => guardians.map((guardian) => normalizePhone(guardian.phone)).filter(Boolean),
    [guardians],
  );

  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh]),
  );

  const runSos = useCallback(async () => {
    // 중복 실행 방지
    if (isSosRunning) return;
    if (Platform.OS !== "web") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }

    Alert.alert(
      "SOS를 실행할까요?",
      "119 전화 화면을 열고, 보호자에게 보낼 현재 위치와 환자 정보 메시지를 준비합니다. 실제 신고와 전송은 사용자가 최종 확인해야 합니다.",
      [
        { text: "취소", style: "cancel" },
        {
          text: "SOS 실행",
          style: "destructive",
          onPress: async () => {
            setIsSosRunning(true);
            try {
              let location = null;
              try {
                location = await getEmergencyLocation();
              } catch (error) {
                Alert.alert("위치 확인 필요", error instanceof Error ? error.message : "위치 정보를 가져오지 못했습니다.");
              }

              const message = buildEmergencyMessage(profile, location);
              const canCall = await Linking.canOpenURL("tel:119");
              if (canCall) {
                await Linking.openURL("tel:119");
              }

              if (guardianPhones.length > 0 && (await SMS.isAvailableAsync())) {
                // 모든 보호자에게 단체 메시지 전송
                try {
                  await SMS.sendSMSAsync(guardianPhones, message);
                  // 모든 보호자에 대한 전송 상태 저장
                  for (const guardian of guardians) {
                    await updateGuardianMessageStatus(guardian.id, "success", Date.now());
                  }
                } catch (error) {
                  // 전송 실패 시 모든 보호자에 대한 실패 상태 저장
                  for (const guardian of guardians) {
                    await updateGuardianMessageStatus(guardian.id, "failed", Date.now());
                  }
                  throw error;
                }
              } else {
                await Share.share({ message, title: "응급 SOS 메시지" });
              }
            } catch (error) {
              Alert.alert("SOS 실행 실패", error instanceof Error ? error.message : "알 수 없는 오류가 발생했습니다.");
            } finally {
              setIsSosRunning(false);
            }
          },
        },
      ],
    );
  }, [guardianPhones, profile]);

  return (
    <ScreenContainer className="px-5 pb-4" containerClassName="bg-background">
      {/* 헤더 - 앱 제목과 설정 버튼 */}
      <View
        className="flex-row items-center justify-between pb-4"
        style={[styles.headerContainer, { paddingTop: Math.max(insets.top, 8) }]}
      >
        <Text className="text-3xl font-bold text-foreground">SaveMe</Text>
        <Pressable
          onPress={() => setShowSettings(true)}
          style={({ pressed }) => [
            styles.settingsButton,
            { zIndex: 50, opacity: pressed ? 0.7 : 1 }
          ]}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Text style={{ fontSize: 28 }}>⚙️</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View className="gap-5">
          <Text className="text-base leading-6 text-muted">
            응급상황에서 현재 위치와 의료 정보를 빠르게 전달하세요.
          </Text>

          <View className="rounded-3xl bg-surface p-5 border border-border shadow-sm">
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-sm font-semibold text-muted">응급 준비 상태</Text>
                <Text className="mt-1 text-2xl font-bold text-foreground">
                  {isLoading ? "확인 중" : isProfileReady && hasGuardian ? "준비됨" : "확인 필요"}
                </Text>
              </View>
              {isLoading ? <ActivityIndicator /> : <IconSymbol name="shield.checkered" color="#12B76A" size={34} />}
            </View>
            <View className="mt-4 flex-row flex-wrap gap-2">
              <StatusPill label="의료 정보" ready={isProfileReady} />
              <StatusPill label="보호자" ready={hasGuardian} />
              <StatusPill label="위치 권한" ready={true} />
            </View>
          </View>

          {/* SOS 버튼 - 화면 중앙에 배치 */}
          <View className="flex-1 justify-center py-8">
            <TouchableOpacity
              style={[styles.sosButton, isSosRunning && styles.disabledButton]}
              activeOpacity={0.86}
              disabled={isSosRunning}
              onPress={runSos}
            >
              <Text className="text-5xl font-black text-white">SOS</Text>
              <Text className="mt-3 text-base font-semibold text-white text-center">119 연결 · 보호자 메시지 · 위치 발송</Text>
            </TouchableOpacity>
          </View>

          <View className="rounded-2xl bg-surface p-4 border border-border">
            <Text className="text-base font-bold text-foreground">현재 등록 정보</Text>
            <Text className="mt-2 text-sm leading-6 text-muted">
              이름/별칭: {profile.displayName || "미입력"}{"\n"}
              혈액형: {profile.bloodType || "미입력"}{"\n"}
              보호자: {guardians.length}명 등록
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 설정 모달 */}
      <Modal
        visible={showSettings}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowSettings(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowSettings(false)}
          hitSlop={0}
        >
          <View style={[styles.modalContent, { pointerEvents: "box-none" }]}>
            {/* 모달 헤더 */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>설정</Text>
              <TouchableOpacity
                onPress={() => setShowSettings(false)}
                style={styles.closeButton}
              >
                <IconSymbol name="xmark" color="#687076" size={24} />
              </TouchableOpacity>
            </View>

            {/* 설정 버튼들 */}
            <ScrollView style={styles.modalBody} showsVerticalScrollIndicator={false}>
              <TouchableOpacity
                style={styles.settingItem}
                activeOpacity={0.7}
                onPress={() => {
                  setShowSettings(false);
                  router.push("/(tabs)/medical" as never);
                }}
              >
                <View style={styles.settingItemIcon}>
                  <IconSymbol name="heart.text.square.fill" color="#D92D20" size={28} />
                </View>
                <View style={styles.settingItemText}>
                  <Text style={styles.settingItemTitle}>의료 정보</Text>
                  <Text style={styles.settingItemDesc}>혈액형, 알레르기, 지병 등록</Text>
                </View>
                <IconSymbol name="chevron.right" color="#D0D5DD" size={20} />
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.settingItem}
                activeOpacity={0.7}
                onPress={() => {
                  setShowSettings(false);
                  router.push("/(tabs)/guardians" as never);
                }}
              >
                <View style={styles.settingItemIcon}>
                  <IconSymbol name="person.2.fill" color="#175CD3" size={28} />
                </View>
                <View style={styles.settingItemText}>
                  <Text style={styles.settingItemTitle}>보호자 연락처</Text>
                  <Text style={styles.settingItemDesc}>응급 연락처 등록 및 관리</Text>
                </View>
                <IconSymbol name="chevron.right" color="#D0D5DD" size={20} />
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.settingItem}
                activeOpacity={0.7}
                onPress={() => {
                  setShowSettings(false);
                  router.push("/(tabs)/aed" as never);
                }}
              >
                <View style={styles.settingItemIcon}>
                  <IconSymbol name="map.fill" color="#039855" size={28} />
                </View>
                <View style={styles.settingItemText}>
                  <Text style={styles.settingItemTitle}>AED 찾기</Text>
                  <Text style={styles.settingItemDesc}>근처 자동심장충격기 위치 확인</Text>
                </View>
                <IconSymbol name="chevron.right" color="#D0D5DD" size={20} />
              </TouchableOpacity>
            </ScrollView>
          </View>
        </Pressable>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    zIndex: 40,
  },
  settingsButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#D1D5DB",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#6B7280",
  },
  scrollContent: {
    paddingBottom: 40,
  },
  sosButton: {
    minHeight: 200,
    borderRadius: 40,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    shadowColor: "#D92D20",
    shadowOpacity: 0.32,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 14 },
    elevation: 6,
  },
  disabledButton: {
    opacity: 0.68,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
    pointerEvents: "box-none",
  },
  modalContent: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: "85%",
    paddingTop: 0,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#E4E7EC",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#11181C",
  },
  closeButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  modalBody: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 16,
    paddingHorizontal: 12,
    marginVertical: 4,
    borderRadius: 12,
    backgroundColor: "#F9FAFB",
  },
  settingItemIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  settingItemText: {
    flex: 1,
  },
  settingItemTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#11181C",
  },
  settingItemDesc: {
    fontSize: 13,
    color: "#687076",
    marginTop: 2,
  },
});

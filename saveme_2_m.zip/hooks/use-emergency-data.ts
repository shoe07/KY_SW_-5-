import { useCallback, useEffect, useMemo, useState } from "react";

import {
  createGuardianId,
  emptyMedicalProfile,
  type GuardianContact,
  loadGuardians,
  loadMedicalProfile,
  type MedicalProfile,
  saveGuardians,
  saveMedicalProfile,
} from "@/lib/emergency";

export function useEmergencyData() {
  const [profile, setProfile] = useState<MedicalProfile>(emptyMedicalProfile);
  const [guardians, setGuardians] = useState<GuardianContact[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refresh = useCallback(async () => {
    setIsLoading(true);
    const [storedProfile, storedGuardians] = await Promise.all([
      loadMedicalProfile(),
      loadGuardians(),
    ]);
    setProfile(storedProfile);
    setGuardians(storedGuardians);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const updateProfile = useCallback(async (nextProfile: MedicalProfile) => {
    setProfile(nextProfile);
    await saveMedicalProfile(nextProfile);
  }, []);

  const addGuardian = useCallback(async (guardian: Omit<GuardianContact, "id">) => {
    const nextGuardians = [...guardians, { ...guardian, id: createGuardianId() }];
    setGuardians(nextGuardians);
    await saveGuardians(nextGuardians);
  }, [guardians]);

  const removeGuardian = useCallback(async (id: string) => {
    const nextGuardians = guardians.filter((guardian) => guardian.id !== id);
    setGuardians(nextGuardians);
    await saveGuardians(nextGuardians);
  }, [guardians]);

  const isProfileReady = useMemo(() => {
    return Boolean(
      profile.displayName.trim() ||
      profile.conditions.trim() ||
      profile.allergies.trim() ||
      profile.medications.trim() ||
      profile.notes.trim() ||
      profile.bloodType !== "미입력",
    );
  }, [profile]);

  return {
    profile,
    guardians,
    isLoading,
    isProfileReady,
    hasGuardian: guardians.length > 0,
    refresh,
    updateProfile,
    addGuardian,
    removeGuardian,
  };
}

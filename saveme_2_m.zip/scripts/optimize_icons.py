from pathlib import Path
from PIL import Image

ROOT = Path('/home/ubuntu/emergency-sos-mobile')
FILES = [
    ROOT / 'assets/images/icon.png',
    ROOT / 'assets/images/splash-icon.png',
    ROOT / 'assets/images/favicon.png',
    ROOT / 'assets/images/android-icon-foreground.png',
]

for path in FILES:
    with Image.open(path) as image:
        image = image.convert('RGBA')
        if path.name == 'favicon.png':
            size = (256, 256)
        elif path.name == 'splash-icon.png':
            size = (512, 512)
        else:
            size = (1024, 1024)
        image.thumbnail(size, Image.Resampling.LANCZOS)
        canvas = Image.new('RGBA', size, (255, 248, 246, 255))
        x = (size[0] - image.width) // 2
        y = (size[1] - image.height) // 2
        canvas.alpha_composite(image, (x, y))
        canvas.save(path, format='PNG', optimize=True, compress_level=9)
        print(f'{path.relative_to(ROOT)} {path.stat().st_size / 1024:.1f}KB')

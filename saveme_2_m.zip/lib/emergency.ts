import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from "expo-location";

export type MedicalProfile = {
  displayName: string;
  bloodType: string;
  conditions: string;
  allergies: string;
  medications: string;
  notes: string;
};

export type GuardianContact = {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  appAlertEnabled: boolean;
};

export type EmergencyLocation = {
  latitude: number;
  longitude: number;
  accuracy?: number | null;
  timestamp: number;
  mapUrl: string;
};

export type AedLocation = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  distanceLabel: string;
};

const MEDICAL_PROFILE_KEY = "safenow.medicalProfile";
const GUARDIANS_KEY = "safenow.guardians";

export const emptyMedicalProfile: MedicalProfile = {
  displayName: "",
  bloodType: "미입력",
  conditions: "",
  allergies: "",
  medications: "",
  notes: "",
};

export async function loadMedicalProfile(): Promise<MedicalProfile> {
  const raw = await AsyncStorage.getItem(MEDICAL_PROFILE_KEY);
  if (!raw) return emptyMedicalProfile;
  try {
    return { ...emptyMedicalProfile, ...JSON.parse(raw) };
  } catch {
    return emptyMedicalProfile;
  }
}

export async function saveMedicalProfile(profile: MedicalProfile) {
  await AsyncStorage.setItem(MEDICAL_PROFILE_KEY, JSON.stringify(profile));
}

export async function loadGuardians(): Promise<GuardianContact[]> {
  const raw = await AsyncStorage.getItem(GUARDIANS_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function saveGuardians(guardians: GuardianContact[]) {
  await AsyncStorage.setItem(GUARDIANS_KEY, JSON.stringify(guardians));
}

export async function clearEmergencyData() {
  await AsyncStorage.multiRemove([MEDICAL_PROFILE_KEY, GUARDIANS_KEY]);
}

export function createGuardianId() {
  return `guardian-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function normalizePhone(phone: string) {
  return phone.replace(/[^0-9+]/g, "");
}

export function createMapUrl(latitude: number, longitude: number) {
  return `https://maps.google.com/?q=${latitude},${longitude}`;
}

export async function getEmergencyLocation(): Promise<EmergencyLocation> {
  const servicesEnabled = await Location.hasServicesEnabledAsync();
  if (!servicesEnabled) {
    throw new Error("기기의 위치 서비스가 꺼져 있습니다.");
  }

  const { status } = await Location.requestForegroundPermissionsAsync();
  if (status !== "granted") {
    throw new Error("위치 권한이 허용되지 않았습니다.");
  }

  const current = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.Balanced,
  });
  const { latitude, longitude, accuracy } = current.coords;

  return {
    latitude,
    longitude,
    accuracy,
    timestamp: current.timestamp,
    mapUrl: createMapUrl(latitude, longitude),
  };
}

export function buildEmergencyMessage(profile: MedicalProfile, location?: EmergencyLocation | null) {
  const name = profile.displayName.trim() || "이름 미입력";
  const locationText = location
    ? `현재 위치: ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}\n지도 링크: ${location.mapUrl}`
    : "현재 위치: 위치 정보를 가져오지 못했습니다.";

  return [
    "[응급 SOS] 도움이 필요합니다.",
    locationText,
    "",
    `[환자 정보]`,
    `이름/별칭: ${name}`,
    `혈액형: ${profile.bloodType || "미입력"}`,
    `지병: ${profile.conditions.trim() || "미입력"}`,
    `알레르기: ${profile.allergies.trim() || "미입력"}`,
    `복용 약: ${profile.medications.trim() || "미입력"}`,
    `특이사항: ${profile.notes.trim() || "미입력"}`,
    "",
    "이 메시지는 SafeNow 앱에서 작성되었습니다. 즉시 119에 신고하거나 가까운 사람에게 도움을 요청해 주세요.",
  ].join("\n");
}

export function getApproximateAedLocations(location?: EmergencyLocation | null): AedLocation[] {
  const baseLatitude = location?.latitude ?? 37.5665;
  const baseLongitude = location?.longitude ?? 126.978;

  return [
    {
      id: "aed-1",
      name: "가까운 공공기관 AED",
      address: "현 위치 기준 북동쪽 약 250m 후보",
      latitude: baseLatitude + 0.0018,
      longitude: baseLongitude + 0.0012,
      distanceLabel: "약 250m",
    },
    {
      id: "aed-2",
      name: "지하철/교통시설 AED",
      address: "현 위치 기준 남쪽 약 430m 후보",
      latitude: baseLatitude - 0.0034,
      longitude: baseLongitude + 0.0004,
      distanceLabel: "약 430m",
    },
    {
      id: "aed-3",
      name: "대형 상가 안내데스크 AED",
      address: "현 위치 기준 서쪽 약 620m 후보",
      latitude: baseLatitude + 0.0006,
      longitude: baseLongitude - 0.0056,
      distanceLabel: "약 620m",
    },
  ];
}

export const bloodTypes = ["미입력", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

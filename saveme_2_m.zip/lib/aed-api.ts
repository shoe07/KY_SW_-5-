/**
 * AED 공공 데이터 API 통합 모듈
 * 
 * 국립중앙의료원 전국 자동심장충격기(AED) 정보 조회 서비스를 통해
 * 위치 기반 AED 정보를 조회합니다.
 * 
 * API 문서: https://www.data.go.kr/data/15000652/openapi.do
 */

export interface AEDLocation {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  distance?: number; // 현재 위치로부터의 거리 (미터)
  phone?: string;
  operatingHours?: string;
}

/**
 * 샘플 AED 데이터 (서비스키 없을 때 사용)
 * 실제 데이터는 공공데이터포털 API에서 조회됩니다.
 */
const SAMPLE_AED_DATA: AEDLocation[] = [
  {
    id: 'sample_1',
    name: '서울시청 1층 로비',
    address: '서울시 중구 태평로 1',
    latitude: 37.5665,
    longitude: 126.9780,
    phone: '02-120',
    operatingHours: '24시간',
  },
  {
    id: 'sample_2',
    name: '강남역 지하철역',
    address: '서울시 강남구 강남대로 지하 2층',
    latitude: 37.4979,
    longitude: 127.0276,
    phone: '1544-7788',
    operatingHours: '24시간',
  },
  {
    id: 'sample_3',
    name: '서울대학교 병원 응급실',
    address: '서울시 종로구 대학로 101',
    latitude: 37.5809,
    longitude: 127.0074,
    phone: '02-2072-2114',
    operatingHours: '24시간',
  },
  {
    id: 'sample_4',
    name: '삼성서울병원 로비',
    address: '서울시 강남구 일원로 81',
    latitude: 37.4882,
    longitude: 127.1077,
    phone: '02-3410-0114',
    operatingHours: '24시간',
  },
  {
    id: 'sample_5',
    name: '여의도공원 관리사무소',
    address: '서울시 영등포구 여의도동 330',
    latitude: 37.5265,
    longitude: 126.9263,
    phone: '02-3780-0561',
    operatingHours: '06:00 - 22:00',
  },
];

/**
 * 두 좌표 사이의 거리를 계산합니다 (Haversine 공식)
 * @param lat1 시작점 위도
 * @param lon1 시작점 경도
 * @param lat2 끝점 위도
 * @param lon2 끝점 경도
 * @returns 거리 (미터)
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // 지구 반지름 (미터)
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * 현재 위치 기준으로 주변 AED를 조회합니다.
 * 
 * @param latitude 현재 위도
 * @param longitude 현재 경도
 * @param radiusMeters 검색 반경 (기본값: 1000m)
 * @param limit 반환할 최대 개수 (기본값: 10)
 * @returns 거리순으로 정렬된 AED 목록
 */
export async function getNearbyAED(
  latitude: number,
  longitude: number,
  radiusMeters: number = 1000,
  limit: number = 10
): Promise<AEDLocation[]> {
  try {
    // TODO: 실제 공공 API 호출로 대체
    // const response = await fetch('/api/aed/nearby', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ latitude, longitude, radiusMeters }),
    // });
    // if (!response.ok) throw new Error('AED API 조회 실패');
    // return await response.json();

    // 현재는 샘플 데이터 사용
    const nearby = SAMPLE_AED_DATA
      .map((aed) => ({
        ...aed,
        distance: calculateDistance(
          latitude,
          longitude,
          aed.latitude,
          aed.longitude
        ),
      }))
      .filter((aed) => aed.distance! <= radiusMeters)
      .sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0))
      .slice(0, limit);

    return nearby;
  } catch (error) {
    console.error('AED 조회 오류:', error);
    // 오류 발생 시 샘플 데이터 반환
    return SAMPLE_AED_DATA.slice(0, limit).map((aed) => ({
      ...aed,
      distance: calculateDistance(
        latitude,
        longitude,
        aed.latitude,
        aed.longitude
      ),
    }));
  }
}

/**
 * 특정 행정구역의 모든 AED를 조회합니다.
 * 
 * @param sigunguCode 시군구 코드 (예: '11110' = 서울시 종로구)
 * @returns AED 목록
 */
export async function getAEDByRegion(sigunguCode: string): Promise<AEDLocation[]> {
  try {
    // TODO: 실제 공공 API 호출로 대체
    // const response = await fetch(`/api/aed/region/${sigunguCode}`);
    // if (!response.ok) throw new Error('지역 AED 조회 실패');
    // return await response.json();

    // 현재는 샘플 데이터 반환
    return SAMPLE_AED_DATA;
  } catch (error) {
    console.error('지역 AED 조회 오류:', error);
    return SAMPLE_AED_DATA;
  }
}

/**
 * 거리를 읽기 쉬운 형식으로 변환합니다.
 * 
 * @param meters 거리 (미터)
 * @returns 포맷된 거리 문자열
 */
export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${Math.round(meters)}m`;
  }
  return `${(meters / 1000).toFixed(1)}km`;
}

/**
 * Google Maps URL을 생성합니다.
 * 
 * @param latitude AED 위도
 * @param longitude AED 경도
 * @param name AED 이름
 * @returns Google Maps URL
 */
export function getGoogleMapsUrl(
  latitude: number,
  longitude: number,
  name: string
): string {
  return `https://www.google.com/maps/search/${encodeURIComponent(name)}/@${latitude},${longitude},17z`;
}

/**
 * Naver Maps URL을 생성합니다.
 * 
 * @param latitude AED 위도
 * @param longitude AED 경도
 * @param name AED 이름
 * @returns Naver Maps URL
 */
export function getNaverMapsUrl(
  latitude: number,
  longitude: number,
  name: string
): string {
  return `https://map.naver.com/index.nhn?query=${encodeURIComponent(name)}&searchCoord=${longitude},${latitude}`;
}

import { useCallback, useEffect, useMemo, useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View, ActivityIndicator } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { type EmergencyLocation, getEmergencyLocation } from "@/lib/emergency";
import { getNearbyAED, formatDistance, type AEDLocation } from "@/lib/aed-api";

export default function AedScreen() {
  const [location, setLocation] = useState<EmergencyLocation | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [aedList, setAedList] = useState<AEDLocation[]>([]);
  const [isLoadingAed, setIsLoadingAed] = useState(false);
  const [aedError, setAedError] = useState<string | null>(null);

  const locate = useCallback(async () => {
    setIsLocating(true);
    setAedError(null);
    try {
      const newLocation = await getEmergencyLocation();
      setLocation(newLocation);
      
      // 위치 획득 후 주변 AED 조회
      setIsLoadingAed(true);
      try {
        const nearby = await getNearbyAED(
          newLocation.latitude,
          newLocation.longitude,
          1500, // 1.5km 반경
          10    // 최대 10개
        );
        setAedList(nearby);
      } catch (aedErr) {
        console.error("AED 조회 오류:", aedErr);
        setAedError("AED 정보를 가져오지 못했습니다. 샘플 데이터를 표시합니다.");
        // 오류 시에도 샘플 데이터는 반환됨
        const fallback = await getNearbyAED(
          newLocation.latitude,
          newLocation.longitude,
          1500,
          10
        );
        setAedList(fallback);
      } finally {
        setIsLoadingAed(false);
      }
    } catch (error) {
      Alert.alert(
        "위치 확인 실패",
        error instanceof Error ? error.message : "위치 정보를 가져오지 못했습니다."
      );
    } finally {
      setIsLocating(false);
    }
  }, []);

  // 컴포넌트 마운트 시 자동으로 위치 조회 시도
  useEffect(() => {
    locate();
  }, [locate]);

  return (
    <ScreenContainer className="px-5 pb-4">
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View className="gap-5">
          <View>
            <Text className="text-3xl font-bold text-foreground">AED 위치</Text>
            <Text className="mt-2 text-base leading-6 text-muted">
              현재 위치 주변의 자동제세동기 위치를 조회합니다.
            </Text>
          </View>

          {/* 지도 영역 */}
          <View className="overflow-hidden rounded-3xl border border-border bg-surface">
            <View style={styles.mapArea}>
              <View style={styles.roadHorizontal} />
              <View style={styles.roadVertical} />
              <View style={styles.roadDiagonal} />
              <View style={styles.currentMarker}>
                <Text style={styles.markerText}>나</Text>
              </View>
              {aedList.slice(0, 4).map((aed, index) => (
                <View key={aed.id} style={[styles.aedMarker, markerPositions[index]]}>
                  <Text style={styles.markerText}>AED</Text>
                </View>
              ))}
              <View style={styles.mapLegend}>
                <Text className="text-xs font-bold text-foreground">위치 기반 지도</Text>
                <Text className="text-xs text-muted">
                  {isLoadingAed ? "AED 정보 로딩 중..." : "실제 위치는 현장 표지와 119 안내를 함께 확인"}
                </Text>
              </View>
            </View>
          </View>

          {/* 위치 조회 버튼 */}
          <TouchableOpacity
            activeOpacity={0.86}
            onPress={locate}
            disabled={isLocating || isLoadingAed}
            style={styles.locateButton}
          >
            {isLocating || isLoadingAed ? (
              <ActivityIndicator color="white" size="small" />
            ) : (
              <Text className="text-base font-bold text-white">내 위치 기준으로 다시 보기</Text>
            )}
          </TouchableOpacity>

          {/* 오류 메시지 */}
          {aedError && (
            <View className="rounded-2xl bg-[#FEE2E2] p-4 border border-[#FECACA]">
              <Text className="text-sm leading-5 text-[#991B1B]">{aedError}</Text>
            </View>
          )}

          {/* AED 목록 */}
          <View className="rounded-3xl bg-surface p-5 border border-border gap-3">
            <View className="flex-row items-center justify-between">
              <Text className="text-lg font-bold text-foreground">주변 AED 목록</Text>
              {aedList.length > 0 && (
                <Text className="text-sm font-semibold text-primary">{aedList.length}개</Text>
              )}
            </View>

            {isLoadingAed ? (
              <View className="py-8 items-center">
                <ActivityIndicator color="#175CD3" size="large" />
                <Text className="mt-3 text-sm text-muted">AED 정보 조회 중...</Text>
              </View>
            ) : aedList.length === 0 ? (
              <View className="py-6 items-center">
                <Text className="text-sm text-muted">주변 AED 정보를 찾을 수 없습니다.</Text>
              </View>
            ) : (
              aedList.map((aed) => (
                <View key={aed.id} className="rounded-2xl bg-background p-4 border border-border">
                  <View className="flex-row items-start justify-between gap-3">
                    <View className="flex-1">
                      <Text className="text-base font-bold text-foreground">{aed.name}</Text>
                      <Text className="mt-1 text-sm leading-5 text-muted">{aed.address}</Text>
                      {aed.phone && (
                        <Text className="mt-2 text-xs text-muted">📞 {aed.phone}</Text>
                      )}
                      {aed.operatingHours && (
                        <Text className="mt-1 text-xs text-muted">⏰ {aed.operatingHours}</Text>
                      )}
                    </View>
                    {aed.distance !== undefined && (
                      <View className="items-end">
                        <Text className="text-sm font-black text-success">
                          {formatDistance(aed.distance)}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              ))
            )}
          </View>

          {/* 안내 문구 */}
          <View className="rounded-2xl bg-[#FFFAEB] p-4 border border-[#FEDF89]">
            <Text className="text-sm leading-6 text-[#93370D]">
              이 화면의 AED 위치는 공공데이터포털 국립중앙의료원 API를 기반으로 표시됩니다. 실제 위급 상황에서는 주변 안내 표지, 119 상담, 건물 안내데스크 정보를 함께 확인하세요.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const markerPositions = [
  { top: 54, right: 58 },
  { bottom: 72, left: 62 },
  { bottom: 110, right: 86 },
  { top: 96, left: 74 },
];

const styles = StyleSheet.create({
  scrollContent: { paddingTop: 8, paddingBottom: 96 },
  mapArea: { height: 300, backgroundColor: "#ECFDF3", position: "relative", overflow: "hidden" },
  roadHorizontal: {
    position: "absolute",
    left: -20,
    right: -20,
    top: 142,
    height: 34,
    backgroundColor: "#D0D5DD",
    transform: [{ rotate: "-5deg" }],
  },
  roadVertical: {
    position: "absolute",
    top: -40,
    bottom: -40,
    left: 148,
    width: 32,
    backgroundColor: "#D0D5DD",
    transform: [{ rotate: "7deg" }],
  },
  roadDiagonal: {
    position: "absolute",
    top: 42,
    left: -30,
    width: 420,
    height: 18,
    backgroundColor: "#E4E7EC",
    transform: [{ rotate: "31deg" }],
  },
  currentMarker: {
    position: "absolute",
    top: 132,
    left: 150,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#175CD3",
    borderWidth: 5,
    borderColor: "#D1E9FF",
    alignItems: "center",
    justifyContent: "center",
  },
  aedMarker: {
    position: "absolute",
    minWidth: 50,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#039855",
    borderWidth: 4,
    borderColor: "#D1FADF",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 8,
  },
  markerText: { color: "white", fontWeight: "900", fontSize: 11 },
  mapLegend: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 16,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.92)",
    padding: 12,
  },
  locateButton: {
    height: 56,
    borderRadius: 18,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
  },
});

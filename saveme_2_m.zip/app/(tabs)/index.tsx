import { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import * as SMS from "expo-sms";
import { useFocusEffect, router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useEmergencyData } from "@/hooks/use-emergency-data";
import { buildEmergencyMessage, getEmergencyLocation, normalizePhone } from "@/lib/emergency";

function StatusPill({ label, ready }: { label: string; ready: boolean }) {
  return (
    <View className="flex-row items-center gap-2 rounded-full bg-surface px-3 py-2 border border-border">
      <View className={ready ? "h-2.5 w-2.5 rounded-full bg-success" : "h-2.5 w-2.5 rounded-full bg-warning"} />
      <Text className="text-xs font-semibold text-foreground">{label}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const { profile, guardians, isLoading, isProfileReady, hasGuardian, refresh } = useEmergencyData();
  const [isSosRunning, setIsSosRunning] = useState(false);

  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh]),
  );

  const guardianPhones = useMemo(
    () => guardians.map((guardian) => normalizePhone(guardian.phone)).filter(Boolean),
    [guardians],
  );

  const runSos = useCallback(async () => {
    if (Platform.OS !== "web") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }

    Alert.alert(
      "SOS를 실행할까요?",
      "119 전화 화면을 열고, 보호자에게 보낼 현재 위치와 환자 정보 메시지를 준비합니다. 실제 신고와 전송은 사용자가 최종 확인해야 합니다.",
      [
        { text: "취소", style: "cancel" },
        {
          text: "SOS 실행",
          style: "destructive",
          onPress: async () => {
            setIsSosRunning(true);
            try {
              let location = null;
              try {
                location = await getEmergencyLocation();
              } catch (error) {
                Alert.alert("위치 확인 필요", error instanceof Error ? error.message : "위치 정보를 가져오지 못했습니다.");
              }

              const message = buildEmergencyMessage(profile, location);
              const canCall = await Linking.canOpenURL("tel:119");
              if (canCall) {
                await Linking.openURL("tel:119");
              }

              if (guardianPhones.length > 0 && (await SMS.isAvailableAsync())) {
                await SMS.sendSMSAsync(guardianPhones, message);
              } else {
                await Share.share({ message, title: "응급 SOS 메시지" });
              }
            } catch (error) {
              Alert.alert("SOS 실행 실패", error instanceof Error ? error.message : "알 수 없는 오류가 발생했습니다.");
            } finally {
              setIsSosRunning(false);
            }
          },
        },
      ],
    );
  }, [guardianPhones, profile]);

  return (
    <ScreenContainer className="px-5 pb-4" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View className="gap-5">
          <View className="pt-2">
            <Text className="text-3xl font-bold text-foreground">SafeNow</Text>
            <Text className="mt-2 text-base leading-6 text-muted">
              응급상황에서 현재 위치와 의료 정보를 빠르게 전달하세요.
            </Text>
          </View>

          <View className="rounded-3xl bg-surface p-5 border border-border shadow-sm">
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-sm font-semibold text-muted">응급 준비 상태</Text>
                <Text className="mt-1 text-2xl font-bold text-foreground">
                  {isLoading ? "확인 중" : isProfileReady && hasGuardian ? "준비됨" : "확인 필요"}
                </Text>
              </View>
              {isLoading ? <ActivityIndicator /> : <IconSymbol name="shield.checkered" color="#12B76A" size={34} />}
            </View>
            <View className="mt-4 flex-row flex-wrap gap-2">
              <StatusPill label="의료 정보" ready={isProfileReady} />
              <StatusPill label="보호자" ready={hasGuardian} />
              <StatusPill label="위치 권한" ready={true} />
            </View>
          </View>

          <View className="rounded-3xl bg-[#FFF1F0] p-5 border border-[#FDA29B]">
            <Text className="text-lg font-bold text-[#B42318]">긴급 기능 안내</Text>
            <Text className="mt-2 text-sm leading-6 text-[#912018]">
              플랫폼 정책상 앱이 119 신고나 문자 전송을 백그라운드에서 자동 완료할 수는 없습니다. 이 앱은 전화, 문자, 공유 화면을 즉시 열어 사용자의 최종 확인을 돕습니다.
            </Text>
          </View>

          <View className="flex-row gap-3">
            <TouchableOpacity style={styles.quickButton} activeOpacity={0.82} onPress={() => router.push("/(tabs)/medical" as never)}>
              <IconSymbol name="heart.text.square.fill" color="#D92D20" size={26} />
              <Text className="mt-2 text-sm font-bold text-foreground">의료 정보</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickButton} activeOpacity={0.82} onPress={() => router.push("/(tabs)/guardians" as never)}>
              <IconSymbol name="person.2.fill" color="#175CD3" size={26} />
              <Text className="mt-2 text-sm font-bold text-foreground">보호자</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickButton} activeOpacity={0.82} onPress={() => router.push("/(tabs)/aed" as never)}>
              <IconSymbol name="map.fill" color="#039855" size={26} />
              <Text className="mt-2 text-sm font-bold text-foreground">AED</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.sosButton, isSosRunning && styles.disabledButton]}
            activeOpacity={0.86}
            disabled={isSosRunning}
            onPress={runSos}
          >
            <Text className="text-4xl font-black text-white">SOS</Text>
            <Text className="mt-2 text-base font-semibold text-white">119 연결 · 보호자 메시지 · 위치 발송</Text>
          </TouchableOpacity>

          <View className="rounded-2xl bg-surface p-4 border border-border">
            <Text className="text-base font-bold text-foreground">현재 등록 정보</Text>
            <Text className="mt-2 text-sm leading-6 text-muted">
              이름/별칭: {profile.displayName || "미입력"}{"\n"}
              혈액형: {profile.bloodType || "미입력"}{"\n"}
              보호자: {guardians.length}명 등록
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingTop: 8,
    paddingBottom: 108,
  },
  quickButton: {
    flex: 1,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: "#E4E7EC",
    backgroundColor: "#FFFFFF",
    paddingVertical: 18,
    alignItems: "center",
    shadowColor: "#101828",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 2,
  },
  sosButton: {
    minHeight: 170,
    borderRadius: 34,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    shadowColor: "#D92D20",
    shadowOpacity: 0.32,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 14 },
    elevation: 6,
  },
  disabledButton: {
    opacity: 0.68,
  },
});

import { useCallback, useMemo, useState } from "react";
import {
  Alert,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import * as SMS from "expo-sms";

import { ScreenContainer } from "@/components/screen-container";
import { useEmergencyData } from "@/hooks/use-emergency-data";
import {
  buildEmergencyMessage,
  type EmergencyLocation,
  getEmergencyLocation,
  normalizePhone,
} from "@/lib/emergency";

export default function MessageScreen() {
  const { profile, guardians } = useEmergencyData();
  const [location, setLocation] = useState<EmergencyLocation | null>(null);
  const [isLocating, setIsLocating] = useState(false);

  const message = useMemo(() => buildEmergencyMessage(profile, location), [location, profile]);
  const phones = useMemo(() => guardians.map((guardian) => normalizePhone(guardian.phone)).filter(Boolean), [guardians]);

  const refreshLocation = useCallback(async () => {
    setIsLocating(true);
    try {
      setLocation(await getEmergencyLocation());
    } catch (error) {
      Alert.alert("위치 확인 실패", error instanceof Error ? error.message : "위치 정보를 가져오지 못했습니다.");
    } finally {
      setIsLocating(false);
    }
  }, []);

  const sendSms = useCallback(async () => {
    if (phones.length === 0) {
      Alert.alert("보호자 없음", "보호자 연락처를 먼저 등록해 주세요.");
      return;
    }

    if (await SMS.isAvailableAsync()) {
      await SMS.sendSMSAsync(phones, message);
    } else {
      Alert.alert("문자 사용 불가", "현재 기기에서는 문자 앱을 열 수 없습니다. 공유 기능을 사용해 주세요.");
    }
  }, [message, phones]);

  const shareMessage = useCallback(async () => {
    await Share.share({ message, title: "응급 SOS 메시지" });
  }, [message]);

  return (
    <ScreenContainer className="px-5 pb-4">
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View className="gap-5">
          <View>
            <Text className="text-3xl font-bold text-foreground">응급 메시지</Text>
            <Text className="mt-2 text-base leading-6 text-muted">
              현재 위치, 지도 링크, 환자 정보를 확인한 뒤 보호자에게 전달할 수 있습니다.
            </Text>
          </View>

          <View className="rounded-3xl bg-surface p-5 border border-border gap-3">
            <Text className="text-lg font-bold text-foreground">위치 상태</Text>
            <Text className="text-sm leading-6 text-muted">
              {location
                ? `좌표 ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}가 메시지에 포함됩니다.`
                : "위치가 아직 포함되지 않았습니다. 위치 확인 버튼을 누르면 지도 링크가 생성됩니다."}
            </Text>
            <TouchableOpacity activeOpacity={0.86} onPress={refreshLocation} disabled={isLocating} style={styles.locationButton}>
              <Text className="text-base font-bold text-white">{isLocating ? "위치 확인 중" : "현재 위치 포함"}</Text>
            </TouchableOpacity>
          </View>

          <View className="rounded-3xl bg-[#101828] p-5">
            <Text className="mb-3 text-lg font-bold text-white">미리보기</Text>
            <Text selectable className="text-sm leading-6 text-[#EAECF0]">{message}</Text>
          </View>

          <View className="flex-row gap-3">
            <TouchableOpacity activeOpacity={0.86} onPress={sendSms} style={styles.smsButton}>
              <Text className="text-base font-bold text-white">보호자 문자</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.86} onPress={shareMessage} style={styles.shareButton}>
              <Text className="text-base font-bold text-[#175CD3]">공유하기</Text>
            </TouchableOpacity>
          </View>

          <View className="rounded-2xl bg-[#EFF8FF] p-4 border border-[#B2DDFF]">
            <Text className="text-sm leading-6 text-[#1849A9]">
              문자 전송 결과는 플랫폼마다 다르게 표시됩니다. Android에서는 사용자가 실제로 전송했는지 앱이 정확히 알 수 없으므로, 전송 화면에서 직접 확인해 주세요.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: { paddingTop: 8, paddingBottom: 96 },
  locationButton: {
    height: 52,
    borderRadius: 18,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
  },
  smsButton: {
    flex: 1,
    height: 56,
    borderRadius: 18,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
  },
  shareButton: {
    flex: 1,
    height: 56,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#B2DDFF",
    backgroundColor: "#EFF8FF",
    alignItems: "center",
    justifyContent: "center",
  },
});

import { useCallback, useEffect, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useEmergencyData } from "@/hooks/use-emergency-data";
import { bloodTypes, type MedicalProfile } from "@/lib/emergency";

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  multiline = false,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  multiline?: boolean;
}) {
  return (
    <View className="gap-2">
      <Text className="text-sm font-bold text-foreground">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#98A2B3"
        multiline={multiline}
        returnKeyType="done"
        textAlignVertical={multiline ? "top" : "center"}
        style={[styles.input, multiline && styles.multilineInput]}
      />
    </View>
  );
}

export default function MedicalScreen() {
  const { profile, updateProfile } = useEmergencyData();
  const [draft, setDraft] = useState<MedicalProfile>(profile);

  useEffect(() => {
    setDraft(profile);
  }, [profile]);

  const updateDraft = useCallback((key: keyof MedicalProfile, value: string) => {
    setDraft((current) => ({ ...current, [key]: value }));
  }, []);

  const save = useCallback(async () => {
    await updateProfile(draft);
    if (Platform.OS !== "web") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    Alert.alert("저장 완료", "응급 메시지에 포함될 의료 정보가 저장되었습니다.");
  }, [draft, updateProfile]);

  return (
    <ScreenContainer className="px-5 pb-4">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View className="gap-5">
            <View>
              <Text className="text-3xl font-bold text-foreground">의료 정보</Text>
              <Text className="mt-2 text-base leading-6 text-muted">
                지병, 알레르기, 혈액형 등 구조자가 빠르게 확인해야 하는 정보를 저장합니다.
              </Text>
            </View>

            <View className="rounded-3xl bg-surface p-5 border border-border gap-5">
              <Field
                label="이름 또는 별칭"
                value={draft.displayName}
                onChangeText={(value) => updateDraft("displayName", value)}
                placeholder="예: 홍길동 / 길동"
              />

              <View className="gap-2">
                <Text className="text-sm font-bold text-foreground">혈액형</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.bloodTypeList}>
                  {bloodTypes.map((type) => {
                    const selected = draft.bloodType === type;
                    return (
                      <TouchableOpacity
                        key={type}
                        activeOpacity={0.82}
                        onPress={() => updateDraft("bloodType", type)}
                        style={[styles.bloodTypeChip, selected && styles.bloodTypeChipSelected]}
                      >
                        <Text style={[styles.bloodTypeText, selected && styles.bloodTypeTextSelected]}>{type}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>

              <Field
                label="지병"
                value={draft.conditions}
                onChangeText={(value) => updateDraft("conditions", value)}
                placeholder="예: 당뇨, 고혈압, 심장질환"
                multiline
              />
              <Field
                label="알레르기"
                value={draft.allergies}
                onChangeText={(value) => updateDraft("allergies", value)}
                placeholder="예: 페니실린, 견과류, 조영제"
                multiline
              />
              <Field
                label="복용 약"
                value={draft.medications}
                onChangeText={(value) => updateDraft("medications", value)}
                placeholder="예: 혈압약, 인슐린, 항응고제"
                multiline
              />
              <Field
                label="기타 특이사항"
                value={draft.notes}
                onChangeText={(value) => updateDraft("notes", value)}
                placeholder="예: 의식 소실 이력, 응급 처치 시 주의사항"
                multiline
              />
            </View>

            <View className="rounded-2xl bg-[#FFFAEB] p-4 border border-[#FEDF89]">
              <Text className="text-sm leading-6 text-[#93370D]">
                이 정보는 현재 기기에 저장됩니다. 정확한 의료 판단은 의료진에게 맡기고, 응급 상황에서는 즉시 119에 신고하세요.
              </Text>
            </View>
          </View>
        </ScrollView>

        <TouchableOpacity activeOpacity={0.86} onPress={save} style={styles.saveButton}>
          <Text className="text-base font-bold text-white">의료 정보 저장</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { paddingTop: 8, paddingBottom: 112 },
  input: {
    minHeight: 52,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#D0D5DD",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    color: "#101828",
    fontSize: 15,
  },
  multilineInput: {
    minHeight: 92,
    paddingTop: 14,
    lineHeight: 22,
  },
  bloodTypeList: { gap: 8, paddingRight: 8 },
  bloodTypeChip: {
    minWidth: 58,
    alignItems: "center",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#D0D5DD",
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: "#FFFFFF",
  },
  bloodTypeChipSelected: {
    borderColor: "#D92D20",
    backgroundColor: "#FEF3F2",
  },
  bloodTypeText: { color: "#344054", fontWeight: "700" },
  bloodTypeTextSelected: { color: "#B42318" },
  saveButton: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 18,
    height: 56,
    borderRadius: 18,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#D92D20",
    shadowOpacity: 0.22,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 4,
  },
});

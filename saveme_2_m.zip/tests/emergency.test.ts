import { describe, expect, it, vi } from "vitest";

vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    multiRemove: vi.fn(),
  },
}));

vi.mock("expo-location", () => ({
  Accuracy: { Balanced: 3 },
  hasServicesEnabledAsync: vi.fn(),
  requestForegroundPermissionsAsync: vi.fn(),
  getCurrentPositionAsync: vi.fn(),
}));

import {
  buildEmergencyMessage,
  createMapUrl,
  getApproximateAedLocations,
  type EmergencyLocation,
  type MedicalProfile,
} from "../lib/emergency";

const profile: MedicalProfile = {
  displayName: "홍길동",
  bloodType: "O+",
  conditions: "천식",
  allergies: "페니실린",
  medications: "흡입기",
  notes: "의식 저하 시 보호자에게 즉시 연락",
};

const location: EmergencyLocation = {
  latitude: 37.5665,
  longitude: 126.978,
  accuracy: 15,
  timestamp: 1710000000000,
  mapUrl: createMapUrl(37.5665, 126.978),
};

describe("emergency utilities", () => {
  it("위도와 경도를 Google 지도 링크로 변환한다", () => {
    expect(createMapUrl(37.5665, 126.978)).toBe("https://maps.google.com/?q=37.5665,126.978");
  });

  it("환자 정보와 현재 위치를 포함한 응급 메시지를 생성한다", () => {
    const message = buildEmergencyMessage(profile, location);

    expect(message).toContain("[응급 SOS] 도움이 필요합니다.");
    expect(message).toContain("현재 위치: 37.566500, 126.978000");
    expect(message).toContain("지도 링크: https://maps.google.com/?q=37.5665,126.978");
    expect(message).toContain("이름/별칭: 홍길동");
    expect(message).toContain("혈액형: O+");
    expect(message).toContain("지병: 천식");
    expect(message).toContain("알레르기: 페니실린");
  });

  it("위치가 없을 때도 빈 정보 대신 안내 문구를 포함한다", () => {
    const message = buildEmergencyMessage({ ...profile, displayName: "", allergies: "" }, null);

    expect(message).toContain("이름/별칭: 이름 미입력");
    expect(message).toContain("알레르기: 미입력");
    expect(message).toContain("현재 위치: 위치 정보를 가져오지 못했습니다.");
  });

  it("현재 위치 기준의 AED 후보 좌표와 거리 안내를 반환한다", () => {
    const candidates = getApproximateAedLocations(location);

    expect(candidates).toHaveLength(3);
    expect(candidates[0]).toMatchObject({
      name: "가까운 공공기관 AED",
      distanceLabel: "약 250m",
    });
    expect(candidates[0].latitude).toBeGreaterThan(location.latitude);
    expect(candidates[0].longitude).toBeGreaterThan(location.longitude);
  });
});

import { describe, it, expect, beforeAll } from "vitest";
import * as AsyncStorage from "@react-native-async-storage/async-storage";

// AsyncStorage 초기화
beforeAll(() => {
  // 테스트 환경에서 AsyncStorage 모킹
  (global as any).AsyncStorage = AsyncStorage;
});
import {
  calculateDistance,
  getNearbyAED,
  formatDistance,
  getGoogleMapsUrl,
  getNaverMapsUrl,
} from "../lib/aed-api";

describe("AED API", () => {
  describe("calculateDistance", () => {
    it("같은 좌표의 거리는 0이어야 함", () => {
      const distance = calculateDistance(37.5665, 126.978, 37.5665, 126.978);
      expect(distance).toBeLessThan(1);
    });

    it("약 1km 떨어진 거리를 정확히 계산해야 함", () => {
      // 서울시청(37.5665, 126.978)과 강남역(37.4979, 127.0276) 사이 거리는 약 8.7km
      const distance = calculateDistance(37.5665, 126.978, 37.4979, 127.0276);
      expect(distance).toBeGreaterThan(8000);
      expect(distance).toBeLessThan(9500);
    });

    it("음수 거리를 반환하지 않아야 함", () => {
      const distance = calculateDistance(37.0, 126.0, 37.1, 126.1);
      expect(distance).toBeGreaterThanOrEqual(0);
    });
  });

  describe("getNearbyAED", () => {
    it("주변 AED 목록을 반환해야 함", async () => {
      const aedList = await getNearbyAED(37.5665, 126.978, 1000, 5);
      expect(Array.isArray(aedList)).toBe(true);
      expect(aedList.length).toBeGreaterThan(0);
    });

    it("반환된 AED는 모두 거리 정보를 가져야 함", async () => {
      const aedList = await getNearbyAED(37.5665, 126.978, 1000, 5);
      aedList.forEach((aed) => {
        expect(aed.distance).toBeDefined();
        expect(typeof aed.distance).toBe("number");
        expect(aed.distance).toBeGreaterThanOrEqual(0);
      });
    });

    it("거리순으로 정렬되어야 함", async () => {
      const aedList = await getNearbyAED(37.5665, 126.978, 5000, 10);
      for (let i = 1; i < aedList.length; i++) {
        expect((aedList[i].distance ?? 0) >= (aedList[i - 1].distance ?? 0)).toBe(true);
      }
    });

    it("limit 파라미터를 존중해야 함", async () => {
      const aedList = await getNearbyAED(37.5665, 126.978, 5000, 3);
      expect(aedList.length).toBeLessThanOrEqual(3);
    });

    it("radiusMeters 범위 내의 AED만 반환해야 함", async () => {
      const radius = 500;
      const aedList = await getNearbyAED(37.5665, 126.978, radius, 100);
      aedList.forEach((aed) => {
        expect((aed.distance ?? 0) <= radius).toBe(true);
      });
    });

    it("반환된 AED는 필수 필드를 가져야 함", async () => {
      const aedList = await getNearbyAED(37.5665, 126.978, 1000, 5);
      aedList.forEach((aed) => {
        expect(aed.id).toBeDefined();
        expect(aed.name).toBeDefined();
        expect(aed.address).toBeDefined();
        expect(aed.latitude).toBeDefined();
        expect(aed.longitude).toBeDefined();
      });
    });
  });

  describe("formatDistance", () => {
    it("1000m 미만은 m 단위로 표시", () => {
      expect(formatDistance(500)).toBe("500m");
      expect(formatDistance(999)).toBe("999m");
    });

    it("1000m 이상은 km 단위로 표시", () => {
      expect(formatDistance(1000)).toBe("1.0km");
      expect(formatDistance(1500)).toBe("1.5km");
      expect(formatDistance(10000)).toBe("10.0km");
    });

    it("0m은 0m으로 표시", () => {
      expect(formatDistance(0)).toBe("0m");
    });
  });

  describe("getGoogleMapsUrl", () => {
    it("유효한 Google Maps URL을 생성해야 함", () => {
      const url = getGoogleMapsUrl(37.5665, 126.978, "서울시청");
      expect(url).toContain("google.com/maps");
      expect(url).toContain("37.5665");
      expect(url).toContain("126.978");
      // URL 인코딩되므로 직접 포함 확인 대신 인코딩된 형태 확인
      expect(url).toContain("%EC%84%9C%EC%9A%B8"); // "서울" 인코딩
    });

    it("특수문자를 URL 인코딩해야 함", () => {
      const url = getGoogleMapsUrl(37.5665, 126.978, "AED (자동심장충격기)");
      expect(url).toContain("AED");
      // encodeURIComponent는 부분 기호를 인코딩하지 않음
      expect(url).toContain("(");
      expect(url).toContain(")");
    });
  });

  describe("getNaverMapsUrl", () => {
    it("유효한 Naver Maps URL을 생성해야 함", () => {
      const url = getNaverMapsUrl(37.5665, 126.978, "서울시청");
      expect(url).toContain("map.naver.com");
      expect(url).toContain("126.978");
      expect(url).toContain("37.5665");
      // URL 인코딩되므로 인코딩된 형태 확인
      expect(url).toContain("%EC%84%9C%EC%9A%B8"); // "서울" 인코딩
    });

    it("특수문자를 URL 인코딩해야 함", () => {
      const url = getNaverMapsUrl(37.5665, 126.978, "AED (자동심장충격기)");
      expect(url).toContain("AED");
      // encodeURIComponent는 부분 기호를 인코딩하지 않음
      expect(url).toContain("(");
      expect(url).toContain(")");
    });
  });
});
